﻿using EXPENSES.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EXPENSES.Controllers
{
    public class SupervisorController : Controller
    {
        // GET: Supervisor
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult SupervisorHome()
        {

            Supervisor sup = (Supervisor)Session["userSupervisor"];
            return View(sup);
        }

    }
}